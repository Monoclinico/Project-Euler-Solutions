I have put here more detailed information about scripts I wrote to solve many problems that are in ProjectEuler.net. I created these small programs with Python as experiments to solve the mathematical problems presented in the described site in the most efficient and fast way that I could do.
If you think you can improve the code, I'll be very grateful if you could help improve the code and make it more efficient, or simplify the code.
If you would like to make any comments, please feel free to send an email to:
matheussanchesleme@gmail.com.

